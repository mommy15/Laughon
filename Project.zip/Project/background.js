chrome.runtime.onInstalled.addListener(() => {
    console.log('Laugh On Me Extension Installed');
  });
  
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'fetchJoke') {
      fetchJoke();
    }
  });
  
  async function fetchJoke() {
    try {
      const response = await fetch('https://v2.jokeapi.dev/joke/Any');
      const data = await response.json();
      const joke = data.type === 'twopart' ? `${data.setup}\n${data.delivery}` : data.joke;
  
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'displayJoke', joke });
      });
    } catch (error) {
      console.error('Error fetching joke:', error);
  
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'error', error: error.message });
      });
    }
  }
  
  