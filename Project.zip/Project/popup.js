document.addEventListener('DOMContentLoaded', function () {
    const fetchJokeBtn = document.getElementById('fetchJokeBtn');
    const jokeDisplay = document.getElementById('joke');
  
    fetchJokeBtn.addEventListener('click', async () => {
      setLoading(true);
  
      try {
        const joke = await fetchJoke();
        displayJoke(joke);
      } catch (error) {
        displayError(error.message);
      } finally {
        setLoading(false);
      }
    });
  
    async function fetchJoke() {
      const response = await fetch('https://v2.jokeapi.dev/joke/Any?type=twopart');
      const data = await response.json();
  
      if (response.ok) {
        return data.type === 'twopart' ? `${data.setup}\n${data.delivery}` : data.joke;
      } else {
        throw new Error(`Failed to fetch joke: ${data.error || response.statusText}`);
      }
    }
  
    function setLoading(isLoading) {
      fetchJokeBtn.disabled = isLoading;
      fetchJokeBtn.textContent = isLoading ? 'Fetching...' : 'Ready For another';
    }
  
    function displayJoke(joke) {
      jokeDisplay.innerText = joke;
    }
  
    function displayError(errorMessage) {
      jokeDisplay.innerText = `Error: ${errorMessage}`;
    }
  });
  