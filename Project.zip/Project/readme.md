# Laugh On Me
Well, when it comes to jokes everybody has an everending smile on their faces, this is an extensin which i have created which generates random jokes 

#### video demo: <https://youtu.be/pZB4m4176jw>

#### Working:
So, This is my Cs50 project which i have created chrome extension using javascript, where this extension gives random jokes at a time...kinda a fun right. By the use of API this extension generates jokes. 

Here the extension consists of five files 
* manifest.json
* background.js
* popup.js
* popup.html
* style.css

The manifest json file provides metadata about the extension such as the name, version and also specifies aspects of extension's functionality

The backoground js file provides the logic for the extension to work accordingly, by the use of API it fetches the data ante provides to the extension 

The popup js files provides the data when it pop's up while clicked what it's function has to during this.

The popup html file provides the layout of the extension a simple Ui design 

The styles css file provides the style for the extension 

thus overall it function as a joke generator which generates jokes whenever the user wants to. 
